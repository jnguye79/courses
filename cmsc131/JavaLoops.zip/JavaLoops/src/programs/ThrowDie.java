package programs;

import java.util.Scanner;
import java.util.Random;

public class ThrowDie {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		System.out.print("How many times to throw a die?: ");
		int dieNum = scan.nextInt();
		
		Random random = new Random(dieNum);
		
		int i = 0;
		while(i <= dieNum) {
			System.out.println("Throw #" + (i+1));
			System.out.println(random.nextInt(6) + " " + random.nextInt(6) + " " + random.nextInt(6));
			System.out.println(random.nextInt(6) + " " + random.nextInt(6) + " " + random.nextInt(6));
			System.out.println(random.nextInt(6) + " " + random.nextInt(6) + " " + random.nextInt(6));
			i++;
		}
		
		scan.close();
	}

}
